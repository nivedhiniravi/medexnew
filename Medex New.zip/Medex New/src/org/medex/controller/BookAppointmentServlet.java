package org.medex.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;


import java.time.format.DateTimeFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.medex.beans.BookAppointment;
import org.medex.beans.Feedback;
import org.medex.service.BookAppointmentService;
import org.medex.service.BookAppointmentServiceImpl;

@WebServlet("/BookAppointmentServlet")
public class BookAppointmentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BookAppointmentService ser=new BookAppointmentServiceImpl();
	
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LocalDateTime now=LocalDateTime.now();
		DateTimeFormatter sf=DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		String time_of_app=sf.format(now);
		response.setContentType("text/html");
        String id=request.getParameter("pid");
        String specialist=request.getParameter("specialist");
        String date_of_app=request.getParameter("date");
        String timeslot=request.getParameter("timeslot");
        String doctorid=request.getParameter("doctor");
      
       
        
        boolean res=ser.showavailableDoctor(new BookAppointment(id,specialist,date_of_app,timeslot,time_of_app,doctorid));
        if(res==true)
        {
        	 RequestDispatcher rd=request.getRequestDispatcher("logout.jsp");
        rd.forward(request, response);
        }
	}

}
